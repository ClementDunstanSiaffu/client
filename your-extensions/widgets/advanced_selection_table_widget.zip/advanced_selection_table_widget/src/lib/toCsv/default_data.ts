
export const defaultParemeters = {
    separator: ',',
    filename: 'generatedBy_react-csv.csv',
    uFEFF: true,
    asyncOnClick: false,
    enclosingCharacter: '"'
  };
  
  export const defaultParametersNotForwarded = [
    `data`,
    `headers`
  ];