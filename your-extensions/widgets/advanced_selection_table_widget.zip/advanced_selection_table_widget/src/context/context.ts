
import {React} from 'jimu-core';

export const AdvancedSelectionTableContext = React.createContext({});
